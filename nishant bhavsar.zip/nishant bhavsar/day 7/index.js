let date = $("#datepicker");
let dialogBtn = $("#dialogBtn")
$(document).ready(function () {
    
    date.datepicker();


    $("#accordion").accordion();
    
    $("#dialog").dialog();
    
    dialogBtn.click(function () {
        
        $("#dialog").dialog();
    })

    $( "#tabs" ).tabs();
  
});